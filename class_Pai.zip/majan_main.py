import random
import class_Pai as Pai
import class_SheetOrder as Sheet


class Game (object):
    # ---[0:初期化
    def __init__(self):
        self.initConfig()
        self.pai_obj = Pai.class_Pai()

        # プレイヤー数
        self.Num_Player = 4
        # 手牌数
        self.Num_Tehai = 13
        # 牌山の列数
        self.Num_Yama = self.pai_obj.Num_Yama
        # 牌山の段数
        self.Num_Yama_Steps = self.pai_obj.Num_Yama_Steps
        # 牌種別数
        self.Num_Pattern = self.pai_obj.Num_Pattern
        # 数字牌の種類
        self.Num_pai = self.pai_obj.Num_pai
        # 風牌の種類
        self.Num_Tsuu_pai = self.pai_obj.Num_Tsuu_pai
        # 三元牌の種類
        self.Num_3gen_pai = self.pai_obj.Num_3gen_pai
        # １種類の牌数
        self.Num_Types = self.pai_obj.Num_Types
        # 牌の合計数　136
        self.Total_pai = self.pai_obj.Total_pai

        # 場
        self.Ba_dict = {
            0: '東', 1: '南', 2: '西', 3: '北'
        }

        self.Sheet = Sheet.class_SheetOrder()

        return

    # ---[1:設定値初期化
    def initConfig(self):
        # ================================
        # 原点
        self.StartPoint = 25000
        # 基準点
        self.BasePoint = 30000
        # ハコ割れドボンの有無
        self.isDobon = False
        # ラス親の Top 時上がり止め
        self.isAgriYame = True
        # リーチ棒が出せない千点以下リーチ可否
        self.isNotHasReach = True
        # 南場における親番で平局（全員聴牌なし）時に流局する
        self.isNanNagere = False
        # 南場における親番の流局判断で、親が聴牌しなければ流局
        # isNanNagere=False,isNanNagerePlus=True 時、親がノー聴牌、他が聴牌のときは流局
        self.isNanNagerePlus = True
        # 流局時自動的に聴牌宣言の可否
        self.isAutoTenpai = True
        # 形式聴牌の可否
        self.isKeisikiTenpai = True
        # 喰いタン可否:True
        self.isKuitan = True
        # 後付け可否:True
        self.isAto = True
        # 完全先付け有無:False
        self.isKanSaki = False
        # 槓裏ドラの有無:True
        self.isKanUra = True
        # 赤ドラの有無:False
        self.isAkadora = False
        # PaiNumber の一巡目 No.0-33 のときの 5 を赤牌とする。赤五萬 No.4,赤筒子 No,13,赤索子 No.22
        # PaiNumber/(Total_pai/Num_Types)==0 のとき、PaiType==0-3 and PaiIndv==(5-1)
        # 3 桁目 1 を付加して区別する。赤五萬 115、赤筒子 125、赤索子 135
        # 半荘以上のルールにおいて一度も上がれない場合の罰可否
        self.isYakitori = False
        self.YakitoriPoint = 3000
        # 5本場以上で二飜縛り可否:True
        self.is5ren = True
        # ウマの有無
        self.isUma = False
        self.UmaPoint = [20000, 10000]

        # ================================
        # ダブルロンあり:True
        self.isDoubleRon = True
        # トリプルロンあり:False
        self.isTripleRon = False
        # 三家和時に上がり無効(isTripleRon が有効時は無視):True
        # ※基本は頭ハネとなる。
        self.isSanTyaNagashi = True
        # オープンリーチの可否:False
        self.isOpenReach = False
        # 流し万貫の可否:True
        self.isNagashiMangan = True
        # フリテンリーチの可否:True
        self.isFuritenReach = True
        # 海底、河底、嶺上、搶槓のみで成立可否:True
        self.isAtoYaku = True
        # ダブル役満の可否:True
        self.isDoubleYakuman = True
        # トリプル役満以上の可否:True
        # ※字一色、大四喜（ダブル）、四暗刻単騎（ダブル）=Max5 倍役満
        self.isTripleYakuman = True
        # 数え役満の可否:True
        self.isKazoeYakuman = True
        # 人和の可否:False
        self.isTyenhoYakuman = False
        # 八連荘の可否:False
        self.isParenYakuman = False
        # 十三不塔の可否:False
        self.isSeasanputaYakuman = False
        # 十三無靠の可否:False
        self.isSeasanushiYakuman = False

    # ---[2:ゲームパラメータの初期化
    def initGame(self):
        # ================================
        # ゲームパラメータの初期化
        # 場
        self.Ba = 0
        # 局
        self.Kyoku = 0
        # 本場
        self.Honba = 0
        # プレイヤー点
        self.PlayerPoint = [self.StartPoint for i in range(self.Num_Player)]
        # プレイヤー焼き鳥
        self.PlayerYakitori = [False for i in range(self.Num_Player)]

        # 場決め
        player = self._set_current_player()
        self.player_oya = player
        self.current_player = player

    # ---[3:プレイヤーエントリー番号をシャッフル
    def _player_order(self):
        # 親決めのくじ引き/サイコロの順番に使用する
        player_order = [i for i in range(self.Num_Player)]
        random.shuffle(player_order)
        return player_order

    # ---[4:起家を直接決める
    def _set_current_player(self):
        player = random.randint(0, 3)
        return player

    # ---[5:場の初期化
    def initBa(self):

        # プレイヤー手牌
        self.PlayerTehai = [list() for i in range(self.Num_Player)]
        # プレイヤー捨牌
        self.PlayerSutehai = [list() for i in range(self.Num_Player)]
        # プレイヤー副露（泣き牌）
        self.PlayerFuro = [list() for i in range(self.Num_Player)]
        # プレイヤー自模牌
        self.PlayerTsumo = [None for i in range(self.Num_Player)]

        # ドラ表示
        self.Dora_List = list()
        # 配牌最大値
        self.Haipai_Max = self.Total_pai - \
            ((self.Num_Yama_Steps*2+1)*self.Num_Player)

        self.haipai_num = 0

    # ---[6:賽の目による割れ目、ドラの初期化
    def initWareme(self, dise):
        # Wareme_indexは親Index=0とした場合のPlayer_index、左回り順
        self.Wareme_index = (dise % self.Num_Player)

        # Indexを右回りにするために奇数(1,3)の入れ替え
        self.Haipai_Yama_Index = (
            self.Num_Player-self.Wareme_index)*(self.Wareme_index % 2)

        self.Haipai_Index = dise*self.Num_Yama_Steps

        # ドラ表示のインデックス
        if dise < 3:
            self.Dora_Yama_Index = self.Haipai_Yama_Index - 1
            if self.Dora_Yama_Index < 0:
                self.Dora_Yama_Index = 3
            self.Dora_Index = (
                self.Num_Yama*self.Num_Yama_Steps-1) - (self.Haipai_Index - 6)
        else:
            self.Dora_Yama_Index = self.Haipai_Yama_Index
            self.Dora_Index = self.Haipai_Index - 6

        DoraView = self.Pai_Yama_List[self.Dora_Yama_Index][self.Dora_Index]

        pai_char, pai_id = self.pai_obj.set_pai_char(DoraView)
        self.Dora_List.append(pai_id)

    def initHaipai(self):
        # 配牌13枚
        # 各プレイヤー3巡目まで4枚ずつ、4巡目は1枚ずつ
        for haipai_num in range(4*self.Num_Player):
            if haipai_num >= 3 * self.Num_Player:
                r = 1
            else:
                r = 4

            # PlayerIndex
            player = haipai_num % self.Num_Player

            self.PlayerTehai[player].extend(
                self.Pai_Yama_List[self.Haipai_Yama_Index][self.Haipai_Index:self.Haipai_Index+r])
            if self.Haipai_Index+r > self.Num_Yama_Steps*self.Num_Yama:
                self.Haipai_Index = self.Haipai_Index + \
                    r - (self.Num_Yama_Steps*self.Num_Yama)
                self.Haipai_Yama_Index += 1
                if self.Haipai_Yama_Index >= 4:
                    self.Haipai_Yama_Index = 0
                self.PlayerTehai[player].extend(
                    self.Pai_Yama_List[self.Haipai_Yama_Index][0:self.Haipai_Index])
            else:
                self.Haipai_Index = self.Haipai_Index+r
                if self.Haipai_Index >= self.Num_Yama_Steps*self.Num_Yama:
                    self.Haipai_Index = 0
                    self.Haipai_Yama_Index += 1
                    if self.Haipai_Yama_Index >= 4:
                        self.Haipai_Yama_Index = 0

        return self.PlayerTehai

    def _Inc_HaiYamaIndex_(self):
        self.Haipai_Index += 1
        if self.Haipai_Index >= self.Num_Yama_Steps*self.Num_Yama:
            self.Haipai_Index = 0
            self.Haipai_Yama_Index += 1
            if self.Haipai_Yama_Index >= 4:
                self.Haipai_Yama_Index = 0
        return

    def tumo(self):
        tumo = self.Pai_Yama_List[self.Haipai_Yama_Index][self.Haipai_Index]
        pai_char, pai_id = self.pai_obj.set_pai_char(tumo)

        self.PlayerTsumo[self.current_player] = pai_id
        self._Inc_HaiYamaIndex_()

        # Debug
        for p in range(self.Num_Player):
            judge_pai = self.PlayerTehai[p]
            if self.PlayerTsumo[p] is not None:
                judge_pai.extend([self.PlayerTsumo[p]])
            pai_char = self.pai_obj.set_haipai_disp(judge_pai)
            print(pai_char)
        return

    def tumo_judge(self):

        judge_pai = self.PlayerTehai[self.current_player] + \
            [self.PlayerTsumo[self.current_player]]

        # ツモ上がりを判断

        # 暗カン、加カンを判断

        return

    def sute_judge(self, sute):

        sute_kind_num = self.pai_obj.get_pai_kind_num(sute)

        shimo_cha = self.current_player + 1
        if shimo_cha == self.Num_Player:
            shimo_cha = 0

        sute_judge = [dict() for i in range(self.Num_Player)]

        for set_dict in sute_judge:
            set_dict.setdefault('pon', list())
            set_dict.setdefault('chee', list())
            set_dict.setdefault('kan', list())
            set_dict.setdefault('ron', list())

        for num, haipai in enumerate(self.PlayerTehai):
            if num != self.current_player:
                haipai_chk = list()
                for pai in haipai:
                    pai_kind_num = self.pai_obj.get_pai_kind_num(pai)
                    haipai_chk.append(pai_kind_num)
                else:
                    # 下家の場合、チーを判断
                    if num == shimo_cha:
                        # 字牌は判断しない。
                        if sute_kind_num[0] < 3:

                            chee_list = list()
                            key_num = sute_kind_num[1]
                            # チーのパターン
                            chee_def = (
                                (-2, -1),
                                (-1, 1),
                                (1, 2),
                            )
                            for chk in chee_def:
                                p1 = key_num + chk[0]
                                p2 = key_num + chk[1]

                                if (p1 >= 0 and p1 < 9) and (p2 >= 0 and p2 < 9):
                                    p1 = (sute_kind_num[0], p1)
                                    p2 = (sute_kind_num[0], p2)

                                    if p1 in haipai_chk and p2 in haipai_chk:

                                        sute_judge[num]['chee'].append(
                                            (p1, p2))
                        pass

                    # ポンを判断
                    if haipai_chk.count(sute_kind_num) == 2:
                        sute_judge[num]['pon'].append(sute_kind_num)

                    # 明カンを判断
                    elif haipai_chk.count(sute_kind_num) == 3:
                        sute_judge[num]['kan'].append(sute_kind_num)

                        pass
                pass
        return sute_judge

    def run(self):
        # ================================
        # GameMenu & Config
        pass

        # ================================
        # プレイヤーエントリー

        # くじ引き順を決める
        player_order = self._player_order()
        # くじを生成
        lottery = self.Sheet.direction_lottery()
        # くじ引き
        pass
        # 場決め
        pass
        # 仮親
        dise1, dise2 = self.Sheet.roll_dise()
        dise = dise1+dise2
        player = (dise % self.Num_Player)-1

        # 省略形
        player = self._set_current_player()

        # 親プレイヤー
        self.player_oya = player
        # 現在のプレイヤー
        self.current_player = player

        # ================================
        # ゲーム初期化
        self.initGame()

        # ================================
        # 局/場のループ
        is_kyokuloop = True
        while(is_kyokuloop):
            # ================================
            # 場の初期化
            self.initBa()

            # ================================
            # 牌山の生成
            self.Pai_Yama_List = self.pai_obj.create_haiyama(self.Num_Player)

            # ================================
            # 親のサイコロ振り
            dise1, dise2 = self.Sheet.roll_dise()

            # ================================
            # 割れ目およびドラ、配牌インデックス
            self.initWareme(dise1+dise2)

            # ================================
            # 配牌13枚ずつ（PaiNumberでの配布）
            self.initHaipai()

            # ================================
            # 配牌を牌種別に変換
            for index, pai_list in enumerate(self.PlayerTehai):
                pai_list.sort()
                haipai_list, haipai_char_list = self.pai_obj.set_haipai_char(
                    pai_list)
                self.PlayerTehai[index] = haipai_list

                # ================================
                # 九種九牌アクション

            # ================================
            # 闘牌のループ
            is_toukailoop = True
            while(is_toukailoop):
                # ================================
                # CurrentPlayerの自模
                self.tumo()

                # ================================
                # CurrentPlayerの自模判定
                self.tumo_judge()

                # ================================
                # 自模上がりアクション

                # ================================
                # 他Playerの明槓/暗槓アクション
                # 槍槓/国士無双の放銃判定

                # ================================
                # CurrentPlayerの捨て牌

                # 捨て牌選択
                pass
                # 捨て牌リスト更新
                pass
                # 捨て牌表示
                pass

                # ================================
                # 他Playerの捨てアクション
                # 放銃判定
                # ポン判定
                # チー判定

                # ================================
                # 流局判定
                # 四風連打判定

                # ================================
                # 闘牌継続
                self.current_player += 1

                if self.current_player >= self.Num_Player:
                    self.current_player = 0

        return


if __name__ == '__main__':
    game = Game()
    game.run()
