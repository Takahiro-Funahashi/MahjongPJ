import random


class class_Pai (object):
    # ---[0:初期値
    def __init__(self):
        # 牌山の列数
        self.Num_Yama = 17
        # 牌山の段数
        self.Num_Yama_Steps = 2
        # 牌種別数
        self.Num_Pattern = 4
        # 数字牌の種類
        self.Num_pai = 9
        # 風牌の種類
        self.Num_Tsuu_pai = 4
        # 三元牌の種類
        self.Num_3gen_pai = 3
        # １種類の牌数
        self.Num_Types = 4
        # 牌の合計数　136
        self.Total_pai = ((self.Num_Pattern-1)*self.Num_pai +
                          self.Num_Tsuu_pai+self.Num_3gen_pai)*self.Num_Types

        # 牌のリスト
        self.Pais_List = list()

        self.Pai_Char_Def = [
            # デバッグ用表示（環境依存）
            # 萬子
            ['一', 'ニ', '三', '四', '五', '六', '七', '八', '九'],
            # 筒子
            ['➀', '➁', '➂', '➃', '➄', '➅', '➆', '➇', '➈'],
            # 索子
            ['１', '２', '３', '４', '５', '６', '７', '８', '９'],
            # 字牌
            ['東', '南', '西', '北', '⬜︎', '発', '中'],
        ]
        self.Pai_Def = [
            # 萬子
            [i for i in range(11, 11+self.Num_pai)],
            # 筒子
            [i for i in range(21, 21+self.Num_pai)],
            # 索子
            [i for i in range(31, 31+self.Num_pai)],
            # 字牌(東南西北白発中)
            [i for i in range(41, 41+self.Num_Tsuu_pai)] + \
            [i for i in range(51, 51+self.Num_3gen_pai)],
        ]

        return

    # ---[1:洗牌
    def shey_pai(self):
        # 牌の合計数分の数字リストを生成
        self.Pais_List = list(range(self.Total_pai))
        # シャッフル（洗牌）
        random.shuffle(self.Pais_List)

        return self.Pais_List

    # ---[2:牌山作成
    def create_haiyama(self, Num_Player):
        # 洗牌
        Pai_Yama_List = self.shey_pai()

        # 牌山を17牌、2段に分ける。
        self.Pai_Yama_List = [
            Pai_Yama_List[
                self.Num_Yama_Steps*self.Num_Yama*i:self.Num_Yama_Steps*self.Num_Yama*(i+1)
            ]
            for i in range(Num_Player)
        ]

        return self.Pai_Yama_List

    # ---[3:牌種を計算
    def get_pai_kind_num(self, PaiNumber):
        PaiType = int(PaiNumber/self.Num_Pattern/self.Num_pai)
        PaiIndv = int(PaiNumber/self.Num_Pattern % self.Num_pai)

        return (PaiType, PaiIndv)

    # ---[4:牌のIDおよび表示文字
    def set_pai_char(self, PaiNumber, isAka=False):
        (PaiType, PaiIndv) = self.get_pai_kind_num(PaiNumber)

        if PaiType < self.Num_Pattern and PaiIndv < self.Num_pai:
            pai_char = self.Pai_Char_Def[PaiType][PaiIndv]
            pai_id = self.Pai_Def[PaiType][PaiIndv]
            if isAka:
                if PaiType >= 0 and PaiType <= 2 and PaiIndv == 5-1:
                    if (PaiNumber % (self.Num_Pattern*self.Num_pai)) % (self.Num_Types*(5-1)) == 0:
                        pai_id += 100

        return pai_char, pai_id

    # ---[5:配牌リストをIDおよび表示文字に変換
    def set_haipai_char(self, haipai, isAka=False):
        haipai_list = list()
        haipai_char_list = list()
        if isinstance(haipai, list):
            for pai in haipai:
                pai_char, pai_id = self.set_pai_char(pai, isAka)
                haipai_list.append(pai_id)
                haipai_char_list.append(pai_char)
        return haipai_list, haipai_char_list

    # ---[5:配牌IDリストを表示文字に変換
    def set_haipai_disp(self, haipai_list, isAka=False):
        disp_list = list()
        for pai in haipai_list:
            pai = pai % 100
            num = pai % 10-1
            pat = int(pai/10)-1
            if pat == 4:  # 三元牌のみ別計算
                pat -= 1
                num += self.Num_Tsuu_pai

            disp_list.append(self.Pai_Char_Def[pat][num])

        return disp_list


if __name__ == '__main__':
    Pai = class_Pai()
    '''
    # 洗牌の確認
    Pais_List = Pai.shey_pai()
    print(Pais_List)
    '''
    for _ in range(10):
        # 牌山の生成
        Pai_Yama_List = Pai.create_haiyama(Num_Player=4)
        '''
        # 牌山の中身を確認
        c_Pai_Yama_List = list()
        for Yama in Pai_Yama_List:
            Yama_list = list()
            # print(len(Yama), Yama)
            for P in Yama:
                # PaiType, PaiIndv = Pai.get_pai_kind_num(PaiNumber=P)
                # print(PaiType, PaiIndv)
                pai_char, pai_id = Pai.set_pai_char(PaiNumber=P, isAka=True)
                # Yama_list.append(pai_char)
                Yama_list.append(pai_id)
            else:
                c_Pai_Yama_List.append(Yama_list)
        else:
            # print(c_Pai_Yama_List)
            key_dict = dict()
            for cYama in c_Pai_Yama_List:
                for key in set(cYama):
                    if key in key_dict:
                        key_dict[key] += cYama.count(key)
                    else:
                        key_dict.setdefault(key, cYama.count(key))
            else:
                print(key_dict)  # 牌の個数をカウントする
                print(len(key_dict.keys()))  # 牌種別数
        '''
        # 仮の配牌時
        haipai = Pai_Yama_List[0][0:14]
        haipai_list, haipai_char_list = Pai.set_haipai_char(haipai, isAka=True)
        print(haipai_list)
        print(haipai_char_list)
